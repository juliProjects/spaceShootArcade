﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
    
public class bullet1 : MonoBehaviour {

	public int speed = 8;
	// Use this for initialization
	void Start () {
		var r2d = GetComponent<Rigidbody2D> ();
		r2d.velocity = new Vector3 (0,speed,0);
	}

	void OnBecameInvisible(){
		Destroy (gameObject);
	}
		
	// Update is called once per frame
	void Update () {
		
	}
}
