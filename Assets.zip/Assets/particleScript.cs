﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class particleScript : MonoBehaviour {

	public float fragilidad;
	public GameObject roca;

	// Use this for initialization
	void Start () {
		roca = GameObject.Find ("particle");
	}

	void OnCollisionEnter (Collision2D obj){
		Instantiate (roca, transform.position + new Vector3 (0, 1, 0), Quaternion.identity); // creamos 2 cachos 
		Instantiate (roca, transform.position + new Vector3 (1, 1, 1), Quaternion.identity); 
		Destroy (gameObject);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
