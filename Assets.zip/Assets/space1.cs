﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class space1 : MonoBehaviour {

	public GameObject bullet;
	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {
 		var r2d = GetComponent<Rigidbody2D>();

		// Move the spaceship when an arrow key is pressed
		if (Input.GetKey("right"))
			r2d.velocity = new Vector3(10,0,0);
		else if (Input.GetKey("left"))
			r2d.velocity = new Vector3(-10,0,0); //AÑADIR MOVIMIENTOS PARA ARRIBA Y ABAJO
		else
			r2d.velocity = new Vector3(0,0,0);

		if (Input.GetKeyDown ("space")) {
			Instantiate (bullet, transform.position, Quaternion.identity);
		}
	}
}

/*TODO*/
/*
- INSERTAR MOVIMIENTOS EN LA NAVE
- HACER QUE LAS PARTICULAS SE GENEREN Y CAIGAN
- HACER QUE EL RAYO DESTRUYA LAS PARTICULAS Y ROCAS
- MIRAR LO DE LA BARRA DE VIDA Y EL SCORE
- AÑADIR LA FUNCIÓN DE HORIZONTAL Y VERTICAL Y PROBAR DE JUGAR CON EL MANDO
- CUANDO LE DA UNA ROCA A LA NAVE QUE EXPLOTE
*/
