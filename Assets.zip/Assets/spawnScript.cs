﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spawnScript : MonoBehaviour {

	public GameObject enemy;
	public Renderer rend;
	public Transform trans;

	public float spawnTime = 2;

	// Use this for initialization
	void Start () {
		InvokeRepeating("addEnemy", 0, spawnTime);
	}
	
	// Update is called once per frame	
	void addEnemy () {
		rend = GetComponent<Renderer>();
		trans = GetComponent<Transform>();

//		float x1 = trans.position.x - rend.bounds.size.x/2;
//		float x2 = trans.position.x - rend.bounds.size.x/2;

		Vector2 spawnpoint = new Vector2(Random.Range(-6.0f, 6.0f), trans.position.y);

		Instantiate (enemy, spawnpoint, Quaternion.identity);
	}
}
