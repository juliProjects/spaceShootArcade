﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyScript : MonoBehaviour {

	public int speed = -5;
	CircleCollider2D explosion_radius;


	public float radius = 5.0f;
	public float power = 10.0f;

	public Transform trans;
	public GameObject explosion, explosionClone;
	public ParticleSystem[] effects;

	// Use this for initialization
	void Start () {
		var r2d = GetComponent<Rigidbody2D> ();
		r2d.velocity = new Vector3 (0,speed,0);
		r2d.angularVelocity = Random.Range (-200,200);
		explosion = GameObject.Find ("Explosion");
		explosionClone = GameObject.Find ("Explosion(Clone)");

	}		

	void OnBecameInvisible(){
		Destroy (gameObject);
	}
		

	// Function called when the enemy collides with another object
	void OnTriggerEnter2D(Collider2D obj) {
		// Name of the object that collided with the enemy
		trans = GetComponent<Transform>();
		var name = obj.gameObject.name;

		// If the enemy collided with a bullet
		if (name == "bullet 1(Clone)") {
			// Destroy itself (the enemy) and the bullet
			Destroy(gameObject);
			Destroy(obj.gameObject);
			Instantiate (explosion, transform.position, Quaternion.identity);
			Destroy(gameObject);
			Destroy (explosionClone);

		}

		// If the enemy collided with the spaceship
		if (name == "spaceship") {
			// Destroy itself (the enemy) to keep things simple
			Destroy(gameObject);
			Instantiate (explosion, transform.position, Quaternion.identity);
			Destroy(gameObject);
			Destroy (explosionClone);
		}
	} 
}
